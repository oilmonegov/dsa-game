// ============================================
// DSA LEARNING GAME - PART 1: CORE STRUCTURE
// ============================================

// Game Configuration
const GAME_CONFIG = {
  totalModules: 5,
  questionsPerModule: 5,
  timeLimit: null, // No time limit, but we track time taken
  passingScore: 70,
  storageKey: 'dsa_game_progress'
};

// Question Bank - Theory Questions
const THEORY_QUESTIONS = [
  {
    id: 't1',
    type: 'mcq',
    category: 'Data Structures Basics',
    question: 'What is a Data Structure?',
    options: [
      'A programming language',
      'A systematic way of organizing and accessing data',
      'A type of computer hardware',
      'A software application'
    ],
    correct: 1,
    explanation: 'A Data Structure is a systematic way of organizing and accessing data needed to solve problems efficiently.',
    realWorld: 'Every app you use - WhatsApp messages (Queue), browser history (Stack), file systems (Tree) - relies on data structures.'
  },
  {
    id: 't2',
    type: 'mcq',
    category: 'Linear vs Non-Linear',
    question: 'Which of the following is a LINEAR data structure?',
    options: ['Tree', 'Graph', 'Array', 'Set'],
    correct: 2,
    explanation: 'Arrays store elements in contiguous memory locations in a sequential manner, making them linear.',
    realWorld: 'Arrays are used everywhere: your contact list, playlist songs, shopping cart items.'
  },
  {
    id: 't3',
    type: 'mcq',
    category: 'Stack Operations',
    question: 'Which principle does a Stack follow?',
    options: ['FIFO (First In First Out)', 'LIFO (Last In First Out)', 'Random Access', 'Priority Based'],
    correct: 1,
    explanation: 'Stack follows LIFO - the last element added is the first one to be removed, like a stack of plates.',
    realWorld: 'Browser back button, Undo/Redo in text editors, function call stack in programming - all use Stack!'
  },
  {
    id: 't4',
    type: 'mcq',
    category: 'Queue Operations',
    question: 'In a Queue, where are elements added and removed?',
    options: [
      'Added at front, removed from front',
      'Added at rear, removed from front',
      'Added at front, removed from rear',
      'Added and removed from same end'
    ],
    correct: 1,
    explanation: 'Queue follows FIFO - elements are added at the rear (enqueue) and removed from the front (dequeue).',
    realWorld: 'Print queue, CPU task scheduling, customer service lines, message queues in apps like WhatsApp.'
  },
  {
    id: 't5',
    type: 'mcq',
    category: 'Tree Terminology',
    question: 'What is the ROOT of a tree?',
    options: [
      'Any node without children',
      'The topmost node with no parent',
      'The bottommost node',
      'A node with exactly two children'
    ],
    correct: 1,
    explanation: 'The root is the topmost node in a tree - it has no parent and all other nodes descend from it.',
    realWorld: 'In a file system, the root is "/" (Linux) or "C:\\" (Windows). In HTML, <html> is the root element.'
  },
  {
    id: 't6',
    type: 'mcq',
    category: 'Tree Terminology',
    question: 'What is a LEAF node in a tree?',
    options: [
      'A node with no parent',
      'A node with exactly one child',
      'A node with no children',
      'The root node'
    ],
    correct: 2,
    explanation: 'A leaf (or external node) is a node with no children - it\'s at the end of a branch.',
    realWorld: 'In a family tree, people with no children are leaves. In a folder structure, files (not folders) are leaves.'
  },
  {
    id: 't7',
    type: 'mcq',
    category: 'Tree Properties',
    question: 'What is the HEIGHT of a tree?',
    options: [
      'The number of nodes in the tree',
      'The length of the longest path from root to a leaf',
      'The number of leaves',
      'The depth of the root'
    ],
    correct: 1,
    explanation: 'Height is the length of the longest path from the root to any leaf. It determines tree efficiency.',
    realWorld: 'A balanced BST with height log(n) can search 1 billion items in just 30 comparisons!'
  },
  {
    id: 't8',
    type: 'mcq',
    category: 'Binary Trees',
    question: 'What makes a tree a BINARY tree?',
    options: [
      'It has exactly 2 nodes',
      'Each node has at most 2 children',
      'It has only 2 levels',
      'All nodes have exactly 2 children'
    ],
    correct: 1,
    explanation: 'A binary tree restricts each node to have AT MOST 2 children (left and right). Nodes can have 0, 1, or 2 children.',
    realWorld: 'Binary Search Trees power database indexes. Heaps (binary trees) manage priority queues in operating systems.'
  },
  {
    id: 't9',
    type: 'mcq',
    category: 'Tree Traversals',
    question: 'What is the order of PREORDER traversal?',
    options: [
      'Left → Root → Right',
      'Root → Left → Right',
      'Left → Right → Root',
      'Level by level'
    ],
    correct: 1,
    explanation: 'Preorder visits Root FIRST (PRE), then left subtree, then right subtree.',
    realWorld: 'Preorder is used to create a copy of a tree, and in expression tree evaluation for prefix notation.'
  },
  {
    id: 't10',
    type: 'mcq',
    category: 'Tree Traversals',
    question: 'Which traversal gives SORTED output from a Binary Search Tree?',
    options: ['Preorder', 'Postorder', 'Inorder', 'Level Order'],
    correct: 2,
    explanation: 'Inorder (Left → Root → Right) visits nodes in ascending order in a BST because left children are always smaller.',
    realWorld: 'Database systems use inorder traversal to retrieve sorted records efficiently.'
  },
  {
    id: 't11',
    type: 'mcq',
    category: 'Algorithm Analysis',
    question: 'What does O(1) time complexity mean?',
    options: [
      'The algorithm takes 1 second',
      'The algorithm runs once',
      'The time is constant regardless of input size',
      'The algorithm has 1 operation'
    ],
    correct: 2,
    explanation: 'O(1) means constant time - the operation takes the same time whether you have 10 items or 10 million.',
    realWorld: 'Array access by index is O(1). Looking up a value in a HashMap is O(1) on average.'
  },
  {
    id: 't12',
    type: 'mcq',
    category: 'Algorithm Analysis',
    question: 'What is the time complexity of Binary Search?',
    options: ['O(1)', 'O(n)', 'O(log n)', 'O(n²)'],
    correct: 2,
    explanation: 'Binary Search halves the search space each step, giving O(log n). For 1 billion items, only ~30 comparisons needed!',
    realWorld: 'Finding a word in a dictionary, searching in sorted databases, autocomplete suggestions.'
  },
  {
    id: 't13',
    type: 'mcq',
    category: 'Algorithm Types',
    question: 'What